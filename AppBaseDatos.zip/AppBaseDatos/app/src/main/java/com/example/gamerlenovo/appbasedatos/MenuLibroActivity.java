package com.example.gamerlenovo.appbasedatos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MenuLibroActivity extends AppCompatActivity {
    private ListView listViewMLMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_libro);
        listViewMLMenu=findViewById(R.id.listViewMLMenu);
    }
}

