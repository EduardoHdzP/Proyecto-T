package com.example.gamerlenovo.appbasedatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    private Button btnAceptar;

    private EditText editTextPassword;
    private EditText editTextUsuario;

    private int tipoUsuario;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAceptar=(Button) findViewById(R.id.btnAceptar);

        spinner=(Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tipoUsuario=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acceder(v);
            }
        });


    }


    public void acceder(View view){
        editTextUsuario=(EditText) findViewById(R.id.editTextUsuario);
        editTextPassword=(EditText) findViewById(R.id.editTextPassword);

        String user=editTextUsuario.getText().toString();
        String pass=editTextPassword.getText().toString();

        switch (tipoUsuario){
            case 1:
                if (user.equals("Eduardo") && pass.equals("1234")){
                   Intent intent=new Intent(getApplicationContext(),MenuPrincipalActivity.class);
                    intent.putExtra("usuario",user);
                    startActivity(intent);
                }
                break;
        }
    }
}
