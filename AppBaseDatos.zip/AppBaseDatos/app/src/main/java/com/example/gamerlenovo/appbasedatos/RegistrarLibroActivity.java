package com.example.gamerlenovo.appbasedatos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gamerlenovo.appbasedatos.modelo.Libro;
import com.example.gamerlenovo.appbasedatos.modelo.TablaLibro;

public class RegistrarLibroActivity extends AppCompatActivity {
    private EditText editTextIsbn;
    private EditText editTextTitulo;
    private EditText editTextAutor;
    private EditText editTextEdicion;
    private EditText editTextEditorial;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_libro);

        Button btnRegistrar=findViewById(R.id.btnRegistrar);
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardar();
            }
        });
    }


    public void guardar(){
        TablaLibro tablaLibro=new TablaLibro(this);
        hacerreferencias();

        if (tablaLibro.existe(editTextIsbn.getText().toString())==null){
            Libro libro=new Libro();
            libro.setIsbn(editTextIsbn.getText().toString());
            libro.setTitulo(editTextTitulo.getText().toString());
            libro.setAutor(editTextAutor.getText().toString());
            libro.setEdicion(editTextEdicion.getText().toString());
            libro.setEditorial(editTextEditorial.getText().toString());
            tablaLibro.guardar(libro);
            Toast.makeText(getApplicationContext(),"Libro guardado",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(),"El libro ya existe",Toast.LENGTH_LONG).show();
        }
    }


    public void hacerreferencias(){
        editTextIsbn=findViewById(R.id.etxtisbn);
        editTextTitulo=findViewById(R.id.etxttitulo);
        editTextAutor=findViewById(R.id.etxtautor);
        editTextEdicion=findViewById(R.id.etxtedicion);
        editTextEditorial=findViewById(R.id.etxteditorial);
    }

}
