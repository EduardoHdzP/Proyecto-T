package com.example.gamerlenovo.appbasedatos.modelo;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class TablaLibro {
    private BaseDatos baseDatos;
    private SQLiteDatabase sqLiteDatabase;
    private Cursor fila;

    private Activity contexto;

    public TablaLibro(Activity contexto) {
        this.contexto = contexto;
        baseDatos=new BaseDatos(contexto,"biblioteca",null,1);
        sqLiteDatabase=baseDatos.getWritableDatabase();

    }


    public Libro existe(String isbn){
        fila=sqLiteDatabase.rawQuery("select * from libro where isbn="+isbn,null);
        if (fila.moveToFirst()){
            Libro libro=new Libro();
            libro.setIsbn(fila.getString(0));
            libro.setTitulo(fila.getString(1));
            libro.setAutor(fila.getString(2));
            libro.setEdicion(fila.getString(3));
            libro.setEditorial(fila.getString(4));
            return libro;
        }else{
            return null;
        }

    }

    public void guardar(Libro libro){
        ContentValues registro=new ContentValues();
        registro.put("isbn",libro.getIsbn());
        registro.put("titulo",libro.getTitulo());
        registro.put("autor",libro.getAutor());
        registro.put("edicion",libro.getEdicion());
        registro.put("editorial",libro.getEditorial());
        sqLiteDatabase.insert("libro",null,registro);
    }

   /* public void eliminar(String isbn){
       int registro=sqLiteDatabase.delete("libro","delete from li").;
       fila.close();
        fila=sqLiteDatabase.rawQuery("select * from isbn from libro where isbn="+isbn,null);

    }*/

    public void modificar(Libro libro){
        ContentValues registro=new ContentValues();
        registro.put("isbn",libro.getIsbn());
        registro.put("titulo",libro.getTitulo());
        registro.put("autor",libro.getAutor());
        registro.put("edicion",libro.getEdicion());
        registro.put("editorial",libro.getEditorial());
        sqLiteDatabase.update("libro",registro,"isbn="+libro.getIsbn(),null);
    }

}
